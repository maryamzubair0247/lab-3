#include <iostream>
#include "myStack.h"
using namespace std;
int main()
{
    int size;
    cout << "Enter stack size ";
    cin >> size;
    myStack<int> s(size);
    int choice, value;
    do
    {
        cout << "\n1.Push element" << endl;
        cout << "2.Pop element" << endl;
        cout << "3.Show top element" << endl;
        cout << "4.Check if stack is empty" << endl;
        cout << "5.Check if stack is full" << endl;
        cout << "6.Display stack elements" << endl;
        cout << "7.Show minimum element" << endl;
        cout << "8.Exit" << endl;
        cin >> choice;

        if (choice == 1)
        {
            cin >> value;
            s.push(value);
        }
        else if (choice == 2)
        {
            cout << "Popped  " << s.pop() << endl;
        }
        else if (choice == 3)
        {
            cout << "Top  " << s.top() << endl;
        }
        else if (choice == 4){
            if (s.isEmpty())
                cout << "empty" << endl;
            else
                cout << "not empty" << endl;
    }
        else if (choice == 5)
        {
            if (s.isFull())
                cout << "Full" << endl;
            else
                cout << "Not Full" << endl;
        }
        else if (choice == 6)
        {
            s.display();
        }
        else if (choice == 7)
        {
            cout << "Minimum  " << s.getMin() << endl;
        }

    } while (choice != 8);

    return 0;
}