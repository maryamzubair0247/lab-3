#pragma once
#include "AbstractStack.h"
#include <iostream>
using namespace std;
template <typename T>
class myStack : public AbstractStack<T>
{
    T* arr;
    T* minArr;
    int capacity;
    int topIndex;
    int minTop;
public:
    myStack(int size)
    {
        capacity = size;
        arr = new T[capacity];
        minArr = new T[capacity];
        topIndex = -1;
        minTop = -1;
    }
    void push(T value)
    {
        if (isFull())
        {
            cout << "Stack Overflow" << endl;
            return;
        }

        arr[++topIndex] = value;

        if (minTop == -1 || value <= minArr[minTop])
            minArr[++minTop] = value;
    }
    T pop()
    {
        if (isEmpty())
        {
            cout << "Stack Underflow" << endl;
            return T();
        }

        T removed = arr[topIndex--];

        if (removed == minArr[minTop])
            minTop--;

        return removed;
    }
    T top() const
    {
        if (isEmpty())
        {
            cout << "Stack is empty" << endl;
            return T();
        }
        return arr[topIndex];
    }
    bool isEmpty() const
    {
        return topIndex == -1;
    }

    bool isFull() const
    {
        return topIndex == capacity - 1;
    }

    void display() const
    {
        for (int i = topIndex; i >= 0; i--)
            cout << arr[i] << " ";
        cout << endl;
    }
    T getMin() const
    {
        if (minTop == -1)
        {
            cout << "Stack is empty" << endl;
            return T();
        }
        return minArr[minTop];
    }
    ~myStack()
    {
        delete[] arr;
        delete[] minArr;
    }
};