#include <iostream>
#include "myStack.h"
using namespace std;

int main()
{
    int size;
    cin >> size;

    myStack<int> s(size);

    int choice, value;

    do
    {
        cin >> choice;

        if (choice == 1)
        {
            cin >> value;
            s.push(value);
        }
        else if (choice == 2)
        {
            cout << s.pop() << endl;
        }
        else if (choice == 3)
        {
            cout << s.top() << endl;
        }
        else if (choice == 4)
        {
            s.display();
        }

    } while (choice != 5);

    return 0;
}