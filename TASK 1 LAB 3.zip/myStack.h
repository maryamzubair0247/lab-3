#pragma once
#include "AbstractStack.h"
#include <iostream>
using namespace std;

template <typename T>
class myStack : public AbstractStack<T>
{
    T* arr;
    int capacity;
    int topIndex;

public:
    myStack(int size)
    {
        capacity = size;
        arr = new T[capacity];
        topIndex = -1;
    }

    void push(T value)
    {
        if (isFull())
        {
            cout << "Stack Overflow" << endl;
            return;
        }
        arr[++topIndex] = value;
    }

    T pop()
    {
        if (isEmpty())
        {
            cout << "Stack Underflow" << endl;
            return T();
        }
        return arr[topIndex--];
    }

    T top() const
    {
        if (isEmpty())
        {
            cout << "Stack is empty" << endl;
            return T();
        }
        return arr[topIndex];
    }

    bool isEmpty() const
    {
        return topIndex == -1;
    }

    bool isFull() const
    {
        return topIndex == capacity - 1;
    }

    void display() const
    {
        for (int i = topIndex; i >= 0; i--)
            cout << arr[i] << " ";
        cout << endl;
    }

    ~myStack()
    {
        delete[] arr;
    }
};