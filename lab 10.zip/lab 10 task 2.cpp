#include<iostream>
using namespace std;

bool palindrome(char str[], int start, int end)
{
    if (start >= end)
        return true;

    if (str[start] != str[end])
        return false;

    return palindrome(str, start + 1, end - 1);
}

int length(char str[], int index = 0)
{
    if (str[index] == '\0')
        return index;

    return length(str, index + 1);
}

int main()
{
    char str[100];

    cout << "Enter String: ";
    cin >> str;

    int len = length(str);

    if (palindrome(str, 0, len - 1))
        cout << "Palindrome";
    else
        cout << "Not Palindrome";

    return 0;
}