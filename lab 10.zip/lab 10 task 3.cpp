#include<iostream>
using namespace std;

int maxElement(int arr[], int size)
{
    if (size == 1)
        return arr[0];

    int maxRest = maxElement(arr, size - 1);

    if (arr[size - 1] > maxRest)
        return arr[size - 1];

    return maxRest;
}

int main()
{
    int arr[] = { 12,5,18,7,3 };

    cout << "Maximum element: " << maxElement(arr, 5);

    return 0;
}