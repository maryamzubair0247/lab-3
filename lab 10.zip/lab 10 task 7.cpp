#include<iostream>
using namespace std;

bool subsetSum(int arr[], int size, int target, int index)
{
    if (target == 0)
        return true;

    if (index == size || target < 0)
        return false;

    return subsetSum(arr, size, target - arr[index], index + 1)
        || subsetSum(arr, size, target, index + 1);
}

int findLargest(int arr[], int size, int index, int largest)
{
    if (index == size)
        return largest;

    if (arr[index] > largest)
        largest = arr[index];

    return findLargest(arr, size, index + 1, largest);
}

int magicNumber(int arr[], int size)
{
    if (size == 0)
        return -1;

    int largest = findLargest(arr, size, 0, arr[0]);

    int temp[100];
    int j = 0;

    for (int i = 0; i < size; i++)
    {
        if (arr[i] != largest)
        {
            temp[j] = arr[i];
            j++;
        }
    }

    if (subsetSum(temp, j, largest, 0))
        return largest;

    int newArr[100];
    int k = 0;

    for (int i = 0; i < size; i++)
    {
        if (arr[i] != largest)
        {
            newArr[k] = arr[i];
            k++;
        }
    }

    return magicNumber(newArr, k);
}

int main()
{
    int arr[] = { 2,3,5,8,13 };

    cout << "Magic Number = " << magicNumber(arr, 5);

    return 0;
}