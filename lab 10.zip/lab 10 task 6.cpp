#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* prev;
    Node* next;
};

void printForward(Node* head)
{
    if (head == NULL)
    {
        cout << endl;
        return;
    }

    cout << head->data << " ";
    printForward(head->next);
}

void printReverse(Node* tail)
{
    if (tail == NULL)
    {
        cout << endl;
        return;
    }

    cout << tail->data << " ";
    printReverse(tail->prev);
}

Node* getTail(Node* head)
{
    if (head == NULL || head->next == NULL)
        return head;

    return getTail(head->next);
}

Node* insertBeginning(Node* head, int value)
{
    Node* newNode = new Node;

    newNode->data = value;
    newNode->prev = NULL;
    newNode->next = head;

    if (head != NULL)
        head->prev = newNode;

    return newNode;
}

Node* insertEnd(Node* head, int value)
{
    if (head == NULL)
    {
        Node* newNode = new Node;

        newNode->data = value;
        newNode->next = NULL;
        newNode->prev = NULL;

        return newNode;
    }

    if (head->next == NULL)
    {
        Node* newNode = new Node;

        newNode->data = value;
        newNode->next = NULL;
        newNode->prev = head;

        head->next = newNode;

        return head;
    }

    head->next = insertEnd(head->next, value);

    return head;
}

Node* insertPosition(Node* head, int value, int pos)
{
    if (pos == 1)
        return insertBeginning(head, value);

    if (head == NULL)
        return NULL;

    if (pos == 2)
    {
        Node* newNode = new Node;

        newNode->data = value;
        newNode->next = head->next;
        newNode->prev = head;

        if (head->next != NULL)
            head->next->prev = newNode;

        head->next = newNode;

        return head;
    }

    head->next = insertPosition(head->next, value, pos - 1);

    return head;
}

Node* deleteValue(Node* head, int value)
{
    if (head == NULL)
        return NULL;

    if (head->data == value)
    {
        Node* temp = head->next;

        if (temp != NULL)
            temp->prev = NULL;

        delete head;
        return temp;
    }

    head->next = deleteValue(head->next, value);

    if (head->next != NULL)
        head->next->prev = head;

    return head;
}

Node* deletePosition(Node* head, int pos)
{
    if (head == NULL)
        return NULL;

    if (pos == 1)
    {
        Node* temp = head->next;

        if (temp != NULL)
            temp->prev = NULL;

        delete head;
        return temp;
    }

    head->next = deletePosition(head->next, pos - 1);

    if (head->next != NULL)
        head->next->prev = head;

    return head;
}

int search(Node* head, int value, int pos = 1)
{
    if (head == NULL)
        return -1;

    if (head->data == value)
        return pos;

    return search(head->next, value, pos + 1);
}

bool palindrome(Node* left, Node* right)
{
    if (left == NULL || right == NULL)
        return true;

    if (left == right)
        return true;

    if (left->next == right)
        return left->data == right->data;

    if (left->data != right->data)
        return false;

    return palindrome(left->next, right->prev);
}

int main()
{
    Node* head = NULL;

    head = insertBeginning(head, 1);
    head = insertEnd(head, 2);
    head = insertEnd(head, 3);
    head = insertEnd(head, 2);
    head = insertEnd(head, 1);

    cout << "Forward: ";
    printForward(head);

    cout << "Reverse: ";
    printReverse(getTail(head));

    cout << "Position of 3: ";
    cout << search(head, 3) << endl;

    if (palindrome(head, getTail(head)))
        cout << "Palindrome List" << endl;
    else
        cout << "Not Palindrome" << endl;

    head = insertPosition(head, 10, 3);

    cout << "After Insert Position: ";
    printForward(head);

    head = deleteValue(head, 10);

    cout << "After Delete Value: ";
    printForward(head);

    head = deletePosition(head, 2);

    cout << "After Delete Position: ";
    printForward(head);

    return 0;
}