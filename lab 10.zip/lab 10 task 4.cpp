#include<iostream>
using namespace std;

struct Node
{
    int data;
    Node* next;
};

void printList(Node* head)
{
    if (head == NULL)
        return;

    cout << head->data << " ";

    printList(head->next);
}

int main()
{
    Node* head = new Node{ 10,NULL };
    head->next = new Node{ 20,NULL };
    head->next->next = new Node{ 30,NULL };

    printList(head);

    return 0;
}