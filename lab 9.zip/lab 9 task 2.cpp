#include<iostream>
using namespace std;

class Player
{
public:
    int id;
    int score;
    Player* next;

    Player(int i, int s)
    {
        id = i;
        score = s;
        next = NULL;
    }
};

class Game
{
private:
    Player* tail;
    Player* current;

public:

    Game()
    {
        tail = NULL;
        current = NULL;
    }

    void addPlayer(int id, int score)
    {
        Player* newPlayer = new Player(id, score);

        if (tail == NULL)
        {
            tail = newPlayer;
            tail->next = tail;
            current = tail;
            return;
        }

        newPlayer->next = tail->next;
        tail->next = newPlayer;
        tail = newPlayer;
    }

    void displayPlayers()
    {
        if (tail == NULL)
            return;

        Player* temp = tail->next;

        cout << "\nPlayers:\n";

        do
        {
            cout << "ID: "
                << temp->id
                << " Score: "
                << temp->score
                << endl;

            temp = temp->next;

        } while (temp != tail->next);
    }

    void nextTurn()
    {
        if (current == NULL)
            return;

        current = current->next;

        cout << "Player "
            << current->id
            << " Turn" << endl;
    }

    void skipPlayer()
    {
        if (current == NULL)
            return;

        current = current->next->next;

        cout << "Skipped One Player" << endl;
        cout << "Now Player "
            << current->id
            << " Turn" << endl;
    }

    void removePlayer(int id)
    {
        if (tail == NULL)
            return;

        Player* curr = tail->next;
        Player* prev = tail;

        do
        {
            if (curr->id == id)
            {
                if (curr == tail && curr == tail->next)
                {
                    delete curr;
                    tail = NULL;
                    current = NULL;
                    return;
                }

                prev->next = curr->next;

                if (curr == tail)
                    tail = prev;

                if (curr == current)
                    current = curr->next;

                delete curr;

                return;
            }

            prev = curr;
            curr = curr->next;

        } while (curr != tail->next);
    }

    void checkWinner()
    {
        if (tail != NULL &&
            tail == tail->next)
        {
            cout << "\nWinner Player ID: "
                << tail->id
                << endl;
        }
    }
};

int main()
{
    Game g;

    g.addPlayer(101, 50);
    g.addPlayer(102, 40);
    g.addPlayer(103, 60);
    g.addPlayer(104, 30);

    g.displayPlayers();

    g.nextTurn();
    g.nextTurn();

    g.skipPlayer();

    g.removePlayer(102);

    g.displayPlayers();

    g.removePlayer(103);
    g.removePlayer(104);

    g.checkWinner();

    return 0;
}