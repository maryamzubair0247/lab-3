#include<iostream>
#include<string>
using namespace std;

class Song
{
public:
    int id;
    string name;
    float duration;
    Song* next;
    Song* prev;

    Song(int i, string n, float d)
    {
        id = i;
        name = n;
        duration = d;
        next = NULL;
        prev = NULL;
    }
};

class Playlist
{
private:
    Song* head;
    Song* current;

public:

    Playlist()
    {
        head = NULL;
        current = NULL;
    }

    void addSong(int id, string name, float duration)
    {
        Song* newSong = new Song(id, name, duration);

        if (head == NULL)
        {
            head = newSong;
            current = head;
            return;
        }

        Song* temp = head;

        while (temp->next != NULL)
        {
            temp = temp->next;
        }

        temp->next = newSong;
        newSong->prev = temp;
    }

    void deleteSong(string name)
    {
        if (head == NULL)
            return;

        Song* temp = head;

        while (temp != NULL && temp->name != name)
        {
            temp = temp->next;
        }

        if (temp == NULL)
        {
            cout << "Song Not Found" << endl;
            return;
        }

        if (temp == head)
        {
            head = head->next;

            if (head != NULL)
                head->prev = NULL;
        }
        else
        {
            temp->prev->next = temp->next;

            if (temp->next != NULL)
                temp->next->prev = temp->prev;
        }

        delete temp;
    }

    void playNext()
    {
        if (current != NULL && current->next != NULL)
        {
            current = current->next;
            cout << "Now Playing: " << current->name << endl;
        }
        else
        {
            cout << "No Next Song" << endl;
        }
    }

    void playPrevious()
    {
        if (current != NULL && current->prev != NULL)
        {
            current = current->prev;
            cout << "Now Playing: " << current->name << endl;
        }
        else
        {
            cout << "No Previous Song" << endl;
        }
    }

    void reversePlaylist()
    {
        Song* temp = NULL;
        Song* currentNode = head;

        while (currentNode != NULL)
        {
            temp = currentNode->prev;
            currentNode->prev = currentNode->next;
            currentNode->next = temp;

            currentNode = currentNode->prev;
        }

        if (temp != NULL)
            head = temp->prev;
    }

    void display()
    {
        Song* temp = head;

        cout << "\nPlaylist\n";

        while (temp != NULL)
        {
            cout << "ID: " << temp->id
                << " Name: " << temp->name
                << " Duration: " << temp->duration
                << endl;

            temp = temp->next;
        }
    }
};

int main()
{
    Playlist p;

    p.addSong(1, "Believer", 3.5);
    p.addSong(2, "Faded", 4.0);
    p.addSong(3, "ShapeOfYou", 3.8);

    p.display();

    p.playNext();
    p.playNext();
    p.playPrevious();

    p.deleteSong("Faded");

    p.display();

    p.reversePlaylist();

    cout << "\nAfter Reverse\n";

    p.display();

    return 0;
}