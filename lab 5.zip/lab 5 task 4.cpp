#include<iostream>
using namespace std;

class Node
{
public:
    int patientID;
    Node* next;
};

class HospitalQueue
{
private:
    Node* head;

public:

    HospitalQueue()
    {
        head = NULL;
    }

    void addPatient(int id)
    {
        Node* newNode = new Node;
        newNode->patientID = id;
        newNode->next = NULL;

        if (head == NULL)
        {
            head = newNode;
            return;
        }

        Node* temp = head;

        while (temp->next != NULL)
        {
            temp = temp->next;
        }

        temp->next = newNode;
    }

    void removePatient(int id)
    {
        if (head == NULL)
        {
            cout << "Queue Empty" << endl;
            return;
        }

        if (head->patientID == id)
        {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }

        Node* temp = head;

        while (temp->next != NULL &&
            temp->next->patientID != id)
        {
            temp = temp->next;
        }

        if (temp->next == NULL)
        {
            cout << "Patient Not Found" << endl;
            return;
        }

        Node* del = temp->next;
        temp->next = del->next;
        delete del;
    }

    void displayPatients()
    {
        if (head == NULL)
        {
            cout << "No Patients" << endl;
            return;
        }

        Node* temp = head;

        while (temp != NULL)
        {
            cout << temp->patientID << " ";
            temp = temp->next;
        }

        cout << endl;
    }

    void countPatients()
    {
        int count = 0;

        Node* temp = head;

        while (temp != NULL)
        {
            count++;
            temp = temp->next;
        }

        cout << "Total Patients = " << count << endl;
    }
};

int main()
{
    HospitalQueue queue;

    queue.addPatient(101);
    queue.addPatient(102);
    queue.addPatient(103);
    queue.addPatient(104);

    cout << "Patient Queue:" << endl;
    queue.displayPatients();

    queue.countPatients();

    cout << "\nPatient 102 Cancelled" << endl;
    queue.removePatient(102);

    queue.displayPatients();

    queue.countPatients();

    return 0;
}