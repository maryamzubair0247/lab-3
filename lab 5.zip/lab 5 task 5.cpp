#include<iostream>
using namespace std;

class StudentNode
{
public:
    int studentID;
    int priority;
    StudentNode* next;
};

class BookQueue
{
private:
    StudentNode* head;

public:

    BookQueue()
    {
        head = NULL;
    }

    void addStudent(int id, int priority)
    {
        StudentNode* newNode = new StudentNode;

        newNode->studentID = id;
        newNode->priority = priority;
        newNode->next = NULL;

        if (head == NULL || priority > head->priority)
        {
            newNode->next = head;
            head = newNode;
            return;
        }

        StudentNode* temp = head;

        while (temp->next != NULL &&
            temp->next->priority >= priority)
        {
            temp = temp->next;
        }

        newNode->next = temp->next;
        temp->next = newNode;
    }

    void cancelReservation(int id)
    {
        if (head == NULL)
            return;

        if (head->studentID == id)
        {
            StudentNode* temp = head;
            head = head->next;
            delete temp;
            return;
        }

        StudentNode* temp = head;

        while (temp->next != NULL &&
            temp->next->studentID != id)
        {
            temp = temp->next;
        }

        if (temp->next != NULL)
        {
            StudentNode* del = temp->next;
            temp->next = del->next;
            delete del;
        }
    }

    void updatePriority(int id, int newPriority)
    {
        cancelReservation(id);
        addStudent(id, newPriority);
    }

    void bookReturned()
    {
        if (head == NULL)
        {
            cout << "No Reservations" << endl;
            return;
        }

        cout << "Book Issued To Student "
            << head->studentID << endl;

        StudentNode* temp = head;
        head = head->next;

        delete temp;
    }

    void displayReservations()
    {
        StudentNode* temp = head;

        while (temp != NULL)
        {
            cout << "Student ID: "
                << temp->studentID
                << " Priority: "
                << temp->priority
                << endl;

            temp = temp->next;
        }
    }

    void countStudents()
    {
        int count = 0;

        StudentNode* temp = head;

        while (temp != NULL)
        {
            count++;
            temp = temp->next;
        }

        cout << "Total Reservations = "
            << count << endl;
    }
};

int main()
{
    BookQueue book1;
    BookQueue book2;

    cout << "BOOK 1" << endl;

    book1.addStudent(101, 3);
    book1.addStudent(102, 1);
    book1.addStudent(103, 5);

    book1.displayReservations();

    book1.countStudents();

    cout << "\nUpdate Priority of 102" << endl;

    book1.updatePriority(102, 6);

    book1.displayReservations();

    cout << "\nBook Returned" << endl;

    book1.bookReturned();

    book1.displayReservations();

    cout << "\nBOOK 2" << endl;

    book2.addStudent(201, 2);
    book2.addStudent(202, 4);
    book2.addStudent(203, 1);

    book2.displayReservations();

    cout << "\nCancel Reservation of 201" << endl;

    book2.cancelReservation(201);

    book2.displayReservations();

    book2.countStudents();

    return 0;
}