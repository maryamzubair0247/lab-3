#include<iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* next;
};

Node* head = NULL;

void insertPosition(int value, int pos)
{
    Node* newNode = new Node;
    newNode->data = value;

    if (pos == 1)
    {
        newNode->next = head;
        head = newNode;
        return;
    }

    Node* temp = head;

    for (int i = 1; i < pos - 1; i++)
    {
        temp = temp->next;
    }

    newNode->next = temp->next;
    temp->next = newNode;
}

void deletePosition(int pos)
{
    if (pos == 1)
    {
        Node* temp = head;
        head = head->next;
        delete temp;
        return;
    }

    Node* temp = head;

    for (int i = 1; i < pos - 1; i++)
    {
        temp = temp->next;
    }

    Node* del = temp->next;
    temp->next = del->next;

    delete del;
}

void search(int value)
{
    Node* temp = head;
    int pos = 1;

    while (temp != NULL)
    {
        if (temp->data == value)
        {
            cout << "Found at position " << pos << endl;
            return;
        }

        temp = temp->next;
        pos++;
    }

    cout << "Not Found" << endl;
}

void countNodes()
{
    Node* temp = head;
    int count = 0;

    while (temp != NULL)
    {
        count++;
        temp = temp->next;
    }

    cout << "Total Nodes = " << count << endl;
}

void display()
{
    Node* temp = head;

    while (temp != NULL)
    {
        cout << temp->data << " ";
        temp = temp->next;
    }

    cout << endl;
}

int main()
{
    int choice;

    do
    {
        cout << "\n1.Insert";
        cout << "\n2.Delete";
        cout << "\n3.Search";
        cout << "\n4.Count";
        cout << "\n5.Display";
        cout << "\n0.Exit";

        cin >> choice;

        if (choice == 1)
        {
            int value, pos;
            cin >> value >> pos;
            insertPosition(value, pos);
        }

        else if (choice == 2)
        {
            int pos;
            cin >> pos;
            deletePosition(pos);
        }

        else if (choice == 3)
        {
            int value;
            cin >> value;
            search(value);
        }

        else if (choice == 4)
        {
            countNodes();
        }

        else if (choice == 5)
        {
            display();
        }

    } while (choice != 0);

    return 0;
}