#include<iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* next;
};

class LinkedList
{
private:
    Node* head;

public:

    LinkedList()
    {
        head = NULL;
    }

    void insertBeginning(int value)
    {
        Node* newNode = new Node;

        newNode->data = value;
        newNode->next = head;

        head = newNode;
    }

    void insertEnd(int value)
    {
        Node* newNode = new Node;

        newNode->data = value;
        newNode->next = NULL;

        if (head == NULL)
        {
            head = newNode;
            return;
        }

        Node* temp = head;

        while (temp->next != NULL)
        {
            temp = temp->next;
        }

        temp->next = newNode;
    }

    void deleteValue(int value)
    {
        if (head == NULL)
            return;

        if (head->data == value)
        {
            Node* temp = head;
            head = head->next;
            delete temp;
            return;
        }

        Node* temp = head;

        while (temp->next != NULL &&
            temp->next->data != value)
        {
            temp = temp->next;
        }

        if (temp->next != NULL)
        {
            Node* del = temp->next;
            temp->next = del->next;
            delete del;
        }
    }

    void display()
    {
        Node* temp = head;

        while (temp != NULL)
        {
            cout << temp->data << " ";
            temp = temp->next;
        }

        cout << endl;
    }
};

int main()
{
    LinkedList list;

    list.insertBeginning(20);
    list.insertBeginning(10);

    list.insertEnd(30);

    list.display();

    list.deleteValue(20);

    list.display();

    return 0;
}